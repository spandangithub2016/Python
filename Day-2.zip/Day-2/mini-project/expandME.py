"""
# http://www.webopedia.com/quick_ref/textmessageabbreviations.asp

Python program for expanding shorten word used in SMS.
Input: 1) A text file have shorten word and their expansion.
       2) A text file/ or text having mixed text and shorten words.

Output: A text file in which all the shorten words are expended.

Example: Input: After reading your jokes, I was LOL.
         Ouput: After reading your jokes, I was laughing out loud.

"""

#Import required modules

#Read the file with shorten words and their expansion.


#Process the file and create a dictonary


#Take user input (file or text)

#Define a function to exapand the shorten word

#Loop through input text, locate the shorten word and call the function.


#Save the processed output.
