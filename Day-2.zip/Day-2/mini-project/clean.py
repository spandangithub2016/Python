"""
Mini project (Day-2): clean raw SMS code file.
Name: 
Email:
"""

# Read the input file

# Open a file to output the processed output

# Loop through line
	# perform required cleaning

	# Write to output file
